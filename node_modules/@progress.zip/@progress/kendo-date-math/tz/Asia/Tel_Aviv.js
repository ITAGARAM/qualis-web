const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Tel_Aviv": "Asia/Jerusalem"
  },
  "rules": {},
  "titles": {
    "Asia/Tel_Aviv": {
      "long": null,
      "group": null
    }
  }
});