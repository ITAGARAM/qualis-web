const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Istanbul": "Europe/Istanbul"
  },
  "rules": {},
  "titles": {
    "Asia/Istanbul": {
      "long": null,
      "group": null
    }
  }
});