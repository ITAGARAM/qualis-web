const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Chungking": "Asia/Shanghai"
  },
  "rules": {},
  "titles": {
    "Asia/Chungking": {
      "long": null,
      "group": null
    }
  }
});