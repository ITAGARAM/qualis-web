const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Dacca": "Asia/Dhaka"
  },
  "rules": {},
  "titles": {
    "Asia/Dacca": {
      "long": null,
      "group": null
    }
  }
});