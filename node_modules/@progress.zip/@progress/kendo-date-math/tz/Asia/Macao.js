const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Macao": "Asia/Macau"
  },
  "rules": {},
  "titles": {
    "Asia/Macao": {
      "long": null,
      "group": null
    }
  }
});