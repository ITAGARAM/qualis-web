const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Ashkhabad": "Asia/Ashgabat"
  },
  "rules": {},
  "titles": {
    "Asia/Ashkhabad": {
      "long": null,
      "group": null
    }
  }
});