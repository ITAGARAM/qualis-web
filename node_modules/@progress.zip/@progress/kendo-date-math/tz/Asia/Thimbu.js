const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Thimbu": "Asia/Thimphu"
  },
  "rules": {},
  "titles": {
    "Asia/Thimbu": {
      "long": null,
      "group": null
    }
  }
});