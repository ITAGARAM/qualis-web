const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Ujung_Pandang": "Asia/Makassar"
  },
  "rules": {},
  "titles": {
    "Asia/Ujung_Pandang": {
      "long": null,
      "group": null
    }
  }
});