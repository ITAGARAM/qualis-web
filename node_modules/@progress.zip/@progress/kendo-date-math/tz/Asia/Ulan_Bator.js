const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Asia/Ulan_Bator": "Asia/Ulaanbaatar"
  },
  "rules": {},
  "titles": {
    "Asia/Ulan_Bator": {
      "long": null,
      "group": null
    }
  }
});