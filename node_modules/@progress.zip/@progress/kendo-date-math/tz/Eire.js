const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Eire": "Europe/Dublin"
  },
  "rules": {},
  "titles": {
    "Eire": {
      "long": null,
      "group": null
    }
  }
});