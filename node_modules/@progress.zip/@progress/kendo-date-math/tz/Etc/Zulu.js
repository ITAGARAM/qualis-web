const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Etc/Zulu": "Etc/UTC"
  },
  "rules": {},
  "titles": {
    "Etc/Zulu": {
      "long": null,
      "group": null
    }
  }
});