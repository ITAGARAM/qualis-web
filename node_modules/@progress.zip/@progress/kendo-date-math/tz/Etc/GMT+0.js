const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Etc/GMT+0": "Etc/GMT"
  },
  "rules": {},
  "titles": {
    "Etc/GMT+0": {
      "long": null,
      "group": null
    }
  }
});