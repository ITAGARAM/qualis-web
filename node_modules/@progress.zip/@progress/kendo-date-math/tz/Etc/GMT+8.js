const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Etc/GMT+8": [
      [
        480,
        "-",
        "-08",
        null
      ]
    ]
  },
  "rules": {},
  "titles": {
    "Etc/GMT+8": {
      "long": null,
      "group": null
    }
  }
});