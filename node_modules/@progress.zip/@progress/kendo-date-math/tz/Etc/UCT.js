const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Etc/UCT": "Etc/UTC"
  },
  "rules": {},
  "titles": {
    "Etc/UCT": {
      "long": null,
      "group": null
    }
  }
});