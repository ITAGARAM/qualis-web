const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Etc/Greenwich": "Etc/GMT"
  },
  "rules": {},
  "titles": {
    "Etc/Greenwich": {
      "long": null,
      "group": null
    }
  }
});