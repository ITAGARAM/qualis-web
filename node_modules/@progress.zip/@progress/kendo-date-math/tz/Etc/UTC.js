const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Etc/UTC": [
      [
        0,
        "-",
        "UTC",
        null
      ]
    ]
  },
  "rules": {},
  "titles": {
    "Etc/UTC": {
      "long": null,
      "group": null
    }
  }
});