const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Etc/Universal": "Etc/UTC"
  },
  "rules": {},
  "titles": {
    "Etc/Universal": {
      "long": null,
      "group": null
    }
  }
});