const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Brazil/West": "America/Manaus"
  },
  "rules": {},
  "titles": {
    "Brazil/West": {
      "long": null,
      "group": null
    }
  }
});