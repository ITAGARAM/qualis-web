const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Brazil/Acre": "America/Rio_Branco"
  },
  "rules": {},
  "titles": {
    "Brazil/Acre": {
      "long": null,
      "group": null
    }
  }
});