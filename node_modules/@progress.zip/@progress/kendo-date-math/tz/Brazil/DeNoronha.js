const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Brazil/DeNoronha": "America/Noronha"
  },
  "rules": {},
  "titles": {
    "Brazil/DeNoronha": {
      "long": null,
      "group": null
    }
  }
});