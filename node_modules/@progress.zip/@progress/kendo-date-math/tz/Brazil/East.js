const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Brazil/East": "America/Sao_Paulo"
  },
  "rules": {},
  "titles": {
    "Brazil/East": {
      "long": null,
      "group": null
    }
  }
});