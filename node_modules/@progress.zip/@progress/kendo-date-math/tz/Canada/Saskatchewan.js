const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Canada/Saskatchewan": "America/Regina"
  },
  "rules": {},
  "titles": {
    "Canada/Saskatchewan": {
      "long": null,
      "group": null
    }
  }
});