const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Canada/Newfoundland": "America/St_Johns"
  },
  "rules": {},
  "titles": {
    "Canada/Newfoundland": {
      "long": null,
      "group": null
    }
  }
});