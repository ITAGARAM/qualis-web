const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Canada/Yukon": "America/Whitehorse"
  },
  "rules": {},
  "titles": {
    "Canada/Yukon": {
      "long": null,
      "group": null
    }
  }
});