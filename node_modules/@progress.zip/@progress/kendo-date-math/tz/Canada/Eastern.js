const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Canada/Eastern": "America/Toronto"
  },
  "rules": {},
  "titles": {
    "Canada/Eastern": {
      "long": null,
      "group": null
    }
  }
});