const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Canada/Central": "America/Winnipeg"
  },
  "rules": {},
  "titles": {
    "Canada/Central": {
      "long": null,
      "group": null
    }
  }
});