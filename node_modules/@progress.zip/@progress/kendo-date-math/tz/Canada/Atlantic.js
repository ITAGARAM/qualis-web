const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Canada/Atlantic": "America/Halifax"
  },
  "rules": {},
  "titles": {
    "Canada/Atlantic": {
      "long": null,
      "group": null
    }
  }
});