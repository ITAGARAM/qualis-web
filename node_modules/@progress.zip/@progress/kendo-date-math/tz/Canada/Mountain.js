const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Canada/Mountain": "America/Edmonton"
  },
  "rules": {},
  "titles": {
    "Canada/Mountain": {
      "long": null,
      "group": null
    }
  }
});