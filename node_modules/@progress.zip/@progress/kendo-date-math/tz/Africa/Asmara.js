const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Africa/Asmara": "Africa/Nairobi"
  },
  "rules": {},
  "titles": {
    "Africa/Asmara": {
      "long": null,
      "group": null
    }
  }
});