const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Africa/Timbuktu": "Africa/Abidjan"
  },
  "rules": {},
  "titles": {
    "Africa/Timbuktu": {
      "long": null,
      "group": null
    }
  }
});