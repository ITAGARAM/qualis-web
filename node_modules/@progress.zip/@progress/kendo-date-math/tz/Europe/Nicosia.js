const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Europe/Nicosia": "Asia/Nicosia"
  },
  "rules": {},
  "titles": {
    "Europe/Nicosia": {
      "long": null,
      "group": null
    }
  }
});