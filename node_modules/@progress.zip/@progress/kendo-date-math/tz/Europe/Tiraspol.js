const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Europe/Tiraspol": "Europe/Chisinau"
  },
  "rules": {},
  "titles": {
    "Europe/Tiraspol": {
      "long": null,
      "group": null
    }
  }
});