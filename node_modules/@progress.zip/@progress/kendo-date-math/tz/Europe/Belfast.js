const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Europe/Belfast": "Europe/London"
  },
  "rules": {},
  "titles": {
    "Europe/Belfast": {
      "long": null,
      "group": null
    }
  }
});