const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Egypt": "Africa/Cairo"
  },
  "rules": {},
  "titles": {
    "Egypt": {
      "long": null,
      "group": null
    }
  }
});