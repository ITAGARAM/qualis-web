const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Chile/EasterIsland": "Pacific/Easter"
  },
  "rules": {},
  "titles": {
    "Chile/EasterIsland": {
      "long": null,
      "group": null
    }
  }
});