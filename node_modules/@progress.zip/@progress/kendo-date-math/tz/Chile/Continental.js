const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Chile/Continental": "America/Santiago"
  },
  "rules": {},
  "titles": {
    "Chile/Continental": {
      "long": null,
      "group": null
    }
  }
});