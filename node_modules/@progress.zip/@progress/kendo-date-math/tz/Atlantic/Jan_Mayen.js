const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Atlantic/Jan_Mayen": "Europe/Oslo"
  },
  "rules": {},
  "titles": {
    "Atlantic/Jan_Mayen": {
      "long": null,
      "group": null
    }
  }
});