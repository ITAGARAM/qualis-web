const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "America/Rosario": "America/Argentina/Cordoba"
  },
  "rules": {},
  "titles": {
    "America/Rosario": {
      "long": null,
      "group": null
    }
  }
});