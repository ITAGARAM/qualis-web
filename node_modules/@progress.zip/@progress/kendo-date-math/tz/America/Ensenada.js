const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "America/Ensenada": "America/Tijuana"
  },
  "rules": {},
  "titles": {
    "America/Ensenada": {
      "long": null,
      "group": null
    }
  }
});