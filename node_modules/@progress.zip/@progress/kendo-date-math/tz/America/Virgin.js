const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "America/Virgin": "America/Port_of_Spain"
  },
  "rules": {},
  "titles": {
    "America/Virgin": {
      "long": null,
      "group": null
    }
  }
});