const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "America/Porto_Acre": "America/Rio_Branco"
  },
  "rules": {},
  "titles": {
    "America/Porto_Acre": {
      "long": null,
      "group": null
    }
  }
});