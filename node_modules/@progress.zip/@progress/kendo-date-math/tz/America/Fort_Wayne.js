const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "America/Fort_Wayne": "America/Indiana/Indianapolis"
  },
  "rules": {},
  "titles": {
    "America/Fort_Wayne": {
      "long": null,
      "group": null
    }
  }
});