const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "America/Argentina/ComodRivadavia": "America/Argentina/Catamarca"
  },
  "rules": {},
  "titles": {
    "America/Argentina/ComodRivadavia": {
      "long": null,
      "group": null
    }
  }
});