const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "America/Knox_IN": "America/Indiana/Knox"
  },
  "rules": {},
  "titles": {
    "America/Knox_IN": {
      "long": null,
      "group": null
    }
  }
});