const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "America/Atka": "America/Adak"
  },
  "rules": {},
  "titles": {
    "America/Atka": {
      "long": null,
      "group": null
    }
  }
});