const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/NSW": "Australia/Sydney"
  },
  "rules": {},
  "titles": {
    "Australia/NSW": {
      "long": null,
      "group": null
    }
  }
});