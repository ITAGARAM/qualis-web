const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/Yancowinna": "Australia/Broken_Hill"
  },
  "rules": {},
  "titles": {
    "Australia/Yancowinna": {
      "long": null,
      "group": null
    }
  }
});