const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/LHI": "Australia/Lord_Howe"
  },
  "rules": {},
  "titles": {
    "Australia/LHI": {
      "long": null,
      "group": null
    }
  }
});