const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/Victoria": "Australia/Melbourne"
  },
  "rules": {},
  "titles": {
    "Australia/Victoria": {
      "long": null,
      "group": null
    }
  }
});