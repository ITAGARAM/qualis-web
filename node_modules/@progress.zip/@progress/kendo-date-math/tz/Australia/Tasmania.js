const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/Tasmania": "Australia/Hobart"
  },
  "rules": {},
  "titles": {
    "Australia/Tasmania": {
      "long": null,
      "group": null
    }
  }
});