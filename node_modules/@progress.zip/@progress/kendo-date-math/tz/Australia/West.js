const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/West": "Australia/Perth"
  },
  "rules": {},
  "titles": {
    "Australia/West": {
      "long": null,
      "group": null
    }
  }
});