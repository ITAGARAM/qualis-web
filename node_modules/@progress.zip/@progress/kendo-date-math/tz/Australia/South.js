const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/South": "Australia/Adelaide"
  },
  "rules": {},
  "titles": {
    "Australia/South": {
      "long": null,
      "group": null
    }
  }
});