const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/Queensland": "Australia/Brisbane"
  },
  "rules": {},
  "titles": {
    "Australia/Queensland": {
      "long": null,
      "group": null
    }
  }
});