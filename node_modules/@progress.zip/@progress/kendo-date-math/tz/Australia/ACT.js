const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/ACT": "Australia/Sydney"
  },
  "rules": {},
  "titles": {
    "Australia/ACT": {
      "long": null,
      "group": null
    }
  }
});