const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/Canberra": "Australia/Sydney"
  },
  "rules": {},
  "titles": {
    "Australia/Canberra": {
      "long": null,
      "group": null
    }
  }
});