const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Australia/North": "Australia/Darwin"
  },
  "rules": {},
  "titles": {
    "Australia/North": {
      "long": null,
      "group": null
    }
  }
});