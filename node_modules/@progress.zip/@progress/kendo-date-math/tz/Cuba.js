const dm = require('@progress/kendo-date-math');
dm.loadTimezone({
  "zones": {
    "Cuba": "America/Havana"
  },
  "rules": {},
  "titles": {
    "Cuba": {
      "long": null,
      "group": null
    }
  }
});