# Kendo UI for Angular

This package is part of the [Kendo UI for Angular](http://www.telerik.com/kendo-angular-ui/) suite.

## License

This is commercial software. To use it, you need to agree to the [**Telerik End User License Agreement for Kendo UI Complete**](http://www.telerik.com/purchase/license-agreement/kendo-ui-complete). If you do not own a commercial license, this file shall be governed by the trial license terms.

All available Kendo UI commercial licenses may be obtained at http://www.telerik.com/purchase/kendo-ui.
